function algo(){
for(var i=1;i<=100;i++);
console.log(i);
if(i%3==0){
    console.log("fizz");
}
if(i%5==0){
    console.log("buzz")
}
}
algo();
function gone(element){
console.log("works")
element.remove();
}
function changeImg(element){
    console.log("works", element);
    element.src = "cactus-s.jpg";
}